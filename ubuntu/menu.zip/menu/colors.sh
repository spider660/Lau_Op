#!/bin/bash
# Centralized Color System for SpiderWebX

CONF_FILE="/home/ubuntu/menu_script/menu/theme.conf"
if [ -f "$CONF_FILE" ]; then
    source "$CONF_FILE"
else
    THEME_COLOR="cyan"
fi

# Base Colors
RED_B='\033[0;31m'
GREEN_B='\033[0;32m'
YELLOW_B='\033[0;33m'
BLUE_B='\033[0;34m'
PURPLE_B='\033[0;35m'
CYAN_B='\033[0;36m'
WHITE_B='\033[0;37m'
NC='\033[0m'

# Theme Assignment
case $THEME_COLOR in
    "red")    COLOR1=$RED_B ;;
    "green")  COLOR1=$GREEN_B ;;
    "yellow") COLOR1=$YELLOW_B ;;
    "blue")   COLOR1=$BLUE_B ;;
    "purple") COLOR1=$PURPLE_B ;;
    "cyan")   COLOR1=$CYAN_B ;;
    "white")  COLOR1=$WHITE_B ;;
    *)        COLOR1=$CYAN_B ;;
esac

# UI Elements
TOP_BORDER="${COLOR1}╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━※❆※━━━━━━━━━━━━━━━━━━━━━━━━╮${NC}"
MID_BORDER="${COLOR1}│${NC}"
BOT_BORDER="${COLOR1}╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━※❆※━━━━━━━━━━━━━━━━━━━━━━━━╯${NC}"
LINE="${COLOR1}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
