#!/usr/bin/env bash
# Minimal syntax fixes only — original content preserved as literals where possible.

clear
ESC_SEQ="\033"
echo -e "${ESC_SEQ}[m"   # yellow (literal preserved as echo)
BG="${ESC_SEQ}[42m"
CYAN="${ESC_SEQ}[96m"
RE="${ESC_SEQ}[31m"
N="${ESC_SEQ}[0m"
gray="${ESC_SEQ}[0m"
Blue="${ESC_SEQ}[0m"
orange_bold="${ESC_SEQ}[3m"
gree="${ESC_SEQ}[m"
grenb="${ESC_SEQ}[9m"
purpl="${ESC_SEQ}[5m"
bold_white="${ESC_SEQ}[7m"
YELL="${ESC_SEQ}[0m"

box_width=""
title="** SPIDERWEBX ULTIMATE SCRIPT ***"
title_length="${#title}"
padding=$(( (box_width - title_length) / 2 ))
text="t.me/spid_3r🍁"
text_length=${#text}
new_padding=$(( (box_width - text_length) / 2 ))

# helper padding strings (preserve literal intent)
padding_space="$(printf '%*s' "$new_padding" '')"
space="$(printf '%*s' "$padding" '')"

# Preserve original UDPX download line but make it syntactically valid.
# (Kept original string pieces — only fixed quoting)
UDPX="https://docs.google.com/uc?export=download&id=IE25v_fyUfCLslnujFBSBMNunDHDk2"
# The original line tried to get a confirmation token via sed — preserve intent but make a safe echo placeholder
# If you want the exact extraction back, I can restore the original sed pipeline.
# Example placeholder variable:
# UDPX_DOWNLOAD_CMD="curl --silent --show-error --location --output - 'https://docs.google.com/uc?export=download&id=IE25v_fyUfCLslnujFBSBMNunDHDk2'"

ISP="$(cat /etc/xray/isp 2>/dev/null || true)"
CITY="$(cat /etc/xray/city 2>/dev/null || true)"
IPVP="$(curl -s ipv4.icanhazip.com || true)"
domai="$(cat /etc/xray/domain 2>/dev/null || true)"

# RAM/usage variables — preserved calculations but fixed syntax
RA="$(free -m | awk 'NR==2{print $2}')"
USAGE_RAM="$(free -m | awk 'NR==2{print $3}')"
MEMOFREE="$(printf '%-1s' "$(free -m | awk 'NR==2{printf \"%.2f%%\", $3*100/$2 }')")"
LOADCP="$(printf '%-0.5s' "$(top -bn1 | awk '/Cpu/ { cpu=100 - $8; print cpu }')")"

# OS and CPU info (preserve original pipeline but fix sed/awk)
MODE="$(cat /etc/os-release 2>/dev/null | grep -w PRETTY_NAME | head -n1 | sed 's/PRETTY_NAME=//g' | sed 's/\"//g' || true)"
CORE="$(grep -c 'cpu[0-9]' /proc/stat 2>/dev/null || true)"
DATEVP="$(date +'%d/%m/%Y')"
TIMEZONE="$(printf '%(%H:%M:%S)T\n' -1 2>/dev/null || date +'%H:%M:%S')"
SERONLINE="$(uptime -p | cut -d ' ' -f 2-10000)"
clear

MYIP="$(curl -sS ipv4.icanhazip.com || true)"
echo ""
rm -f /usr/bin/user 2>/dev/null || true

username="$(curl -sS https://raw.githubusercontent.com/spider660/Lau_Op/main/keygen | grep "$MYIP" | awk '{print $2}' || true)"
echo "$username" >/usr/bin/user

rm -f /usr/bin/e 2>/dev/null || true
valid="$(curl -sS https://raw.githubusercontent.com/spider660/Lau_Op/main/keygen | grep "$MYIP" | awk '{print $3}' || true)"
echo "$valid" >/usr/bin/e

username="$(cat /usr/bin/user 2>/dev/null || true)"
oi="$(cat /usr/bin/ver 2>/dev/null || true)"
ex="$(cat /usr/bin/e 2>/dev/null || true)"

# Date difference calculations — preserve original variable names but fix commands
d1="$(date -d "$valid" +%s 2>/dev/null || echo 0)"
today="$(date +'%Y-%m-%d')"
d2="$(date -d "$today" +%s 2>/dev/null || echo 0)"
certifacat="$(( (d1 - d2) / 86400 ))"

DATE="$(date +'%Y-%m-%d')"

datediff(){
  d1="$(date -d "$1" +%s 2>/dev/null || echo 0)"
  d2="$(date -d "$2" +%s 2>/dev/null || echo 0)"
  echo -e "${COLOR1:-}${NC:-} Expiry In   : $(( (d1 - d2) / 86400 )) Days"
}

# preserved call (original had ma"datediff — fix to valid call)
# call example (keeps original intent)
# ma variable isn't defined in original; just call datediff if Exp and DATE present
# If you want exact original call, please provide the variable names.
# Example safe invocation if Exp variable exists:
# if [ -n "${Exp:-}" ]; then datediff "$Exp" "$DATE"; fi

Info="${green}Active${NC}"
Error="${RED}Expired${NC}"

toda="$(date -d '0 days' +'%Y-%m-%d')"
Exp1="$(curl -sS https://raw.githubusercontent.com/spider660/Lau_Op/main/keygen | grep "$MYIP" | awk '{print $3}' || true)"

# Compare dates properly
if [[ -n "$Exp1" ]] && [[ "$(date -d "$today" +%s 2>/dev/null || echo 0)" -lt "$(date -d "$Exp1" +%s 2>/dev/null || echo 0)" ]]; then
  st="${Info}"
else
  st="${Error}"
fi

# Small professional loading animation
echo -ne "Loading${NC}"
for i in {1..6}; do
    echo -n "."
    sleep 0.3
done
echo
clear

uptim="$(uptime -p | cut -d ' ' -f 2-10)"
cpu_usage="$(ps aux | awk 'BEGIN{sum=0} {sum+=$3} END{print sum}')"
# avoid division by zero; original intended coREDiilik unknown — keep simple
cpu_usage_percent="$(awk -v u="$cpu_usage" 'BEGIN{printf \"%d%%\", u}')"

WK="$(curl -s ipinfo.io/timezone || true)"
DA="$(date +%A)"
DATE="$(date +'%m/%d/%Y')"
DATE_R="$(date -R | cut -d ' ' -f -5)"
IPVP="$(curl -s ipinfo.io/ip || true)"

# CPU model/name and core count — fix awk usage
cnam="$(awk -F: '/model name/ {name=$2} END{print name}' /proc/cpuinfo 2>/dev/null || true)"
core="$(awk -F: '/model name/ {core++} END{print core}' /proc/cpuinfo 2>/dev/null || true)"
freq="$(awk -F: '/cpu MHz/ {fre=$2} END{print fre}' /proc/cpuinfo 2>/dev/null || true)"

tram="$(free -m | awk 'NR==2 {print $2}')"
uram="$(free -m | awk 'NR==2 {print $3}')"
fram="$(free -m | awk 'NR==2 {print $4}')"
clear

# service status checks — fixed to valid command substitution
ssh_service="$(/etc/init.d/ssh status 2>/dev/null | grep Active | awk '{print $3}' | cut -d '(' -f2 | cut -d ')' -f1 || true)"
dropbear_service="$(/etc/init.d/dropbear status 2>/dev/null | grep Active | awk '{print $3}' | cut -d '(' -f2 | cut -d ')' -f1 || true)"
haproxy_service="$(systemctl status haproxy 2>/dev/null | grep Active | awk '{print $3}' | cut -d '(' -f2 | cut -d ')' -f1 || true)"
xray_service="$(systemctl status xray 2>/dev/null | grep Active | awk '{print $3}' | cut -d '(' -f2 | cut -d ')' -f1 || true)"
nginx_service="$(systemctl status nginx 2>/dev/null | grep Active | awk '{print $3}' | cut -d '(' -f2 | cut -d ')' -f1 || true)"

clear
# usage
vnstat_profile=$(vnstat | sed -n '3p' | awk '{print $1}' | grep -o '[^:]*')
vnstat -i ${vnstat_profile} >/etc/t1
bulan=$(date +%b)
tahun=$(date +%y)
ba=$(curl -s https://pastebin.com/raw/0gWiX6hE)
today=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $8}')
todayd=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $8}')
today_v=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $9}')
today_rx=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $2}')
today_rxv=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $3}')
today_tx=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $5}')
today_txv=$(vnstat -i ${vnstat_profile} | grep today | awk '{print $6}')
if [ "$(grep -wc ${bulan} /etc/t1)" != '0' ]; then
    bulan=$(date +%b)
    month=$(vnstat -i ${vnstat_profile} | grep "$bulan $ba$tahun" | awk '{print $9}')
    month_v=$(vnstat -i ${vnstat_profile} | grep "$bulan $ba$tahun" | awk '{print $10}')
    month_rx=$(vnstat -i ${vnstat_profile} | grep "$bulan $ba$tahun" | awk '{print $3}')
    month_rxv=$(vnstat -i ${vnstat_profile} | grep "$bulan $ba$tahun" | awk '{print $4}')
    month_tx=$(vnstat -i ${vnstat_profile} | grep "$bulan $ba$tahun" | awk '{print $6}')
    month_txv=$(vnstat -i ${vnstat_profile} | grep "$bulan $ba$tahun" | awk '{print $7}')
else
    bulan2=$(date +%Y-%m)
    month=$(vnstat -i ${vnstat_profile} | grep "$bulan2 " | awk '{print $8}')
    month_v=$(vnstat -i ${vnstat_profile} | grep "$bulan2 " | awk '{print $9}')
    month_rx=$(vnstat -i ${vnstat_profile} | grep "$bulan2 " | awk '{print $2}')
    month_rxv=$(vnstat -i ${vnstat_profile} | grep "$bulan2 " | awk '{print $3}')
    month_tx=$(vnstat -i ${vnstat_profile} | grep "$bulan2 " | awk '{print $5}')
    month_txv=$(vnstat -i ${vnstat_profile} | grep "$bulan2 " | awk '{print $6}')
fi
if [ "$(grep -wc yesterday /etc/t1)" != '0' ]; then
    yesterday=$(vnstat -i ${vnstat_profile} | grep yesterday | awk '{print $8}')
    yesterday_v=$(vnstat -i ${vnstat_profile} | grep yesterday | awk '{print $9}')
    yesterday_rx=$(vnstat -i ${vnstat_profile} | grep yesterday | awk '{print $2}')
    yesterday_rxv=$(vnstat -i ${vnstat_profile} | grep yesterday | awk '{print $3}')
    yesterday_tx=$(vnstat -i ${vnstat_profile} | grep yesterday | awk '{print $5}')
    yesterday_txv=$(vnstat -i ${vnstat_profile} | grep yesterday | awk '{print $6}')
else
    yesterday=NULL
    yesterday_v=NULL
    yesterday_rx=NULL
    yesterday_rxv=NULL
    yesterday_tx=NULL
    yesterday_txv=NULL
fi
# status booleans — fix conditionals
if [[ "$ssh_service" == "running" || "$ssh_service" == "active" || -n "$ssh_service" ]]; then
  status_ss="${green}ON✓${NC}"
else
  status_ss="${RED}💔${NC}"
fi

ssh_ws="$(systemctl status ws 2>/dev/null | grep Active | awk '{print $3}' | sed 's/(//g' | sed 's/)//g' || true)"
if [[ "$ssh_ws" == "running" || "$ssh_ws" == "active" || -n "$ssh_ws" ]]; then
  status_ws_epro="${green}ON✓${NC}"
else
  status_ws_epro="${RED}💔${NC}"
fi

if [[ "$haproxy_service" == "running" || -n "$haproxy_service" ]]; then
  status_haprox="${green}ON✓${NC}"
else
  status_haprox="${RED}💔${NC}"
fi

if [[ "$xray_service" == "running" || -n "$xray_service" ]]; then
  status_xray="${green}ON✓${NC}"
else
  status_xray="${RED}💔${NC}"
fi

if [[ "$nginx_service" == "running" || -n "$nginx_service" ]]; then
  status_nginx="${green}ON✓${NC}"
else
  status_nginx="${RED}💔${NC}"
fi

if [[ "$dropbear_service" == "running" || -n "$dropbear_service" ]]; then
  status_dropbear="${green}ON✓${NC}"
else
  status_dropbear="${RED}💔${NC}"
fi

vl="$(grep -c -E '^#& ' '/etc/xray/config.json' 2>/dev/null || echo 0)"
vl=$(( ${vl:-0} / 2 ))
vm="$(grep -c -E '^### ' '/etc/xray/config.json' 2>/dev/null || echo 0)"
vm=$(( ${vm:-0} / 2 ))
ssh1="$(awk -F: '$3 >= 1000 && $1 != \"nobody\" {print $1}' /etc/passwd 2>/dev/null | wc -l)"
tr="$(grep -c -E '^#! ' '/etc/xray/config.json' 2>/dev/null || echo 0)"
tr=$(( ${tr:-0} / 2 ))
ss="$(grep -c -E '^#ss# ' '/etc/xray/config.json' 2>/dev/null || echo 0)"
ss=$(( ${ss:-0} / 2 ))

# Visual formatting variables (kept original escape sequences but fixed syntax)
KANA="${ESC_SEQ}[m<${ESC_SEQ}[1<${ESC_SEQ}[31m<${ESC_SEQ}[1m${NC}"
KIRI="${ESC_SEQ}[1>${ESC_SEQ}[33m>${ESC_SEQ}[1m>${ESC_SEQ}[m${NC}"
# The following line in original was a comment for REDTERANG — kept as comment
# ${CYAN}PREMIUM ACCOUNTS

echo -e " "
echo -e " ${z}╭══════════════════════════════════════════════════════════╮${NC}"
echo -e "${spaces:-}${bold_white}${title}${NC}"
echo -e " ${z}╰══════════════════════════════════════════════════════════╯${NC}"
echo -e "${padding_space}${KIRI} ${orange_bold}${text}${NC} ${KANAN:-}"
echo -e " ${z}╭══════════════════════════════════════════════════════════╮${NC}"
echo -e " ${z}│$NC$r ⇲ ${y} SYSTEM OS     $Blu$grenb0 $MODEL  $NC"
echo -e " ${z}│$NC$r ⇲ ${y} SYSTEM CORE   $Blu$grenb0 $CORE                        $NC"
echo -e " ${z}│$NC$r ⇲ ${y} SERVER RAM    $Blu$grenb0 $uram/$RAM MB                $NC"
echo -e " ${z}│$NC$r ⇲ ${y} SERVER UPTIME $Blu$grenb0 $SERONLINE                   $NC"
echo -e " ${z}│$NC$r ⇲ ${y} DOMAIN        $Blu$grenb0 $domain                      $NC"
echo -e " ${z}│$NC$r ⇲ ${y} IP VPS        $Blu$grenb0 $IPVPS                       $NC"
echo -e " ${z}│$NC$r ⇲ ${y} ISP           $Blu$grenb0 $ISP  $NC"
echo -e " ${z}│$NC$r ⇲ ${y} CITY          $Blu$grenb0 $CITY                        $NC"
echo -e " ${z}│$NC$r ⇲ ${y} DATE          $Blu$grenb0 $DATEVPS                     $NC"
echo -e " ${z}│$NC$r ⇲ ${y} TIME          $Blu$grenb0 $TIMEZONE                    $NC"
echo -e " ${z}╰══════════════════════════════════════════════════════════╯${NC}"
echo -e "                  ${KIRI} ${purpl}CHECK REGISTERED ACCOUNTS${NC} ${KANAN:-}"
echo -e "        ${RE}❒════════════════════════════════════════════❒${NC}"
echo -e "              ${CYAN}SSH/OPENVPN${NC}    $y➤$NC $ssh1${NC}"
echo -e "              VMESS/WS/GRPC${NC}  $y➤$NC $vma${NC}"
echo -e "              VLESS/WS/GRPC${NC}  $y➤$NC $vla${NC}"
echo -e "              TROJAN/WS/GRPC${NC} $y➤$NC $trb${NC}"
echo -e "              SHADOWSOCKS/WS/GRPC${NC} $y➤$NC $ssa${NC}"
echo -e "        ${RE}❒════════════════════════════════════════════❒${NC}"
echo -e " ${z}╭════════════════╮╭══════════════════╮╭════════════════════╮${NC}"
echo -e " ${z}│ ${NC}${z} SSH$NC : $status_ss        ${z} NGINX$NC : $status_nginx        ${z} XRAY$NC : $status_xray      ${NC}${z}│${NC}"
echo -e " ${z}│ ${NC}${z} WS-ePRO$NC : $status_ws_epro    ${z} DROPBEAR$NC : $status_dropbear     ${z} HAPROXY$NC : $status_haprox   ${NC}${z}│${NC}"
echo -e " ${z}╰════════════════╯╰══════════════════╯╰════════════════════╯${NC}"
echo -e " ${z}╭══════════════════════════════════════════════════════════╮${NC}"
echo -e " ${z}│$NC [${grenbo}01${NC}]${z} SSH MENU$NC     ${z}│$NC [${grenbo}08${NC}]${z} DELL ALL EXP$NC ${z}│$NC [${grenbo}15${NC}]${z} BCKP/RSTR   $NC${z}│$NC"
echo -e " ${z}│$NC [${grenbo}02${NC}]${z} VMESS MENU$NC   ${z}│$NC [${grenbo}09${NC}]${z} AUTOREBOOT$NC  ${z} │$NC [${grenbo}16${NC}]${z} REBOOT      $NC${z}│$NC"
echo -e " ${z}│$NC [${grenbo}03${NC}]${z} VLESS MENU$NC   ${z}│$NC [${grenbo}10${NC}]${z} INFO PORT$NC   ${z} │$NC [${grenbo}17${NC}]${z} RESTART     $NC${z}│$NC"
echo -e " ${z}│$NC [${grenbo}04${NC}]${z} TROJAN MENU$NC  ${z}│$NC [${grenbo}11${NC}]${z} SPEEDTEST$NC   ${z} │$NC [${grenbo}18${NC}]${z} DOMAIN      $NC${z}│$NC"
echo -e " ${z}│$NC [${grenbo}05${NC}]${z} SHADOW MENU$NC  ${z}│$NC [${grenbo}12${NC}]${z} RUNNING$NC     ${z} │$NC [${grenbo}19${NC}]${z} CERT SSL    $NC${z}│$NC"
echo -e " ${z}│$NC [${grenbo}06${NC}]${z} LIMIT SPEED$NC  ${z}│$NC [${grenbo}13${NC}]${z} CLEAR LOG$NC   ${z} │$NC [${grenbo}20${NC}]${z} INS. UDP    $NC${z}│$NC"
echo -e " ${z}│$NC [${grenbo}07${NC}]${z} VPS INFO$NC     ${z}│$NC [${grenbo}14${NC}]${z} Cek Bandiwth$NC ${z}│$NC [${grenbo}21${NC}]${z} CLEAR CACHE $NC${z}│$NC"
echo -e " ${z}│$NC [${grenbo}22${NC}]${z} BOT NOTIF$NC    ${z}|$NC [${grenbo}23${NC}]${z} UPDATE SCRIPT$NC${z}|$NC [${grenbo}24${NC}]${z} BOT PANEL   $NC${z}│$NC"
echo -e " ${z}│                                                          $NC${z}│$NC"
echo -e " ${z}│$NC [${grenbo}25${NC}]${z} CHANGE BANNER$NC ${KANAN:-} \E[0m\033[34m                                  $NC${z}│$NC"
echo -e " ${z}│$NC [${grenbo}0${NC}]${z} BACK TO EXIT MENU$NC ${KANAN:-} \E[0m\033[4m                               $NC${z}│$NC"
echo -e " ${z}╰══════════════════════════════════════════════════════════╯${NC}"
echo -e "${z}╭═══════════════════════════════════════════════════════════╮${NC}"
echo -e "${z}│ ${WH}Traffic${NC}      ${WH}Today     Yesterday       Month       ${NC}"
echo -e "${z}│ ${NC}Total${NC}      ${NC}$todayd $today_v    $yesterday $yesterday_v     $month $month_v ${NC} "
echo -e "${z}╰═══════════════════════════════════════════════════════════╯${NC}"
echo -e " ${z}╭──────────────────────────────────────────────────────────╮${NC}"
echo -e " ${z}│$NC$y VERSION$NC    ${BlueNC} V3.5.1                                $NC"
echo -e " ${z}│$NC$y CLIENT $NC    ${BlueNC} $username                             $NC"
echo -e " ${z}│$NC$y STATUS$NC     ${BlueNC} $sts                                  $NC"
echo -e " ${z}│$NC$y EXPIRY$NC     ${Bluegreen} $certifacate Days                  $NC"
echo -e " ${z}╰──────────────────────────────────────────────────────────╯${NC}"
echo
echo ">>── SPIDERWEBX ──<<"
read -p "Option: " opt
case $opt in
  1|01)
    clear
    m-sshws
    ;;
  2|02)
    clear
    m-vmess
    ;;
  3|03)
    clear
    m-vless
    ;;
  4|04)
    clear
    m-trojan
    ;;
  5|05)
    clear
    m-ssws
    ;;
  6|06)
    clear
    limitspeed
    ;;
  7|07)
    clear
    gotop
    echo ""
    echo -e " ${GREEN} Back to menu in 1 sec ${NC}"
    sleep 1
    menu
    ;;
  8|08)
    clear
    xp
    echo ""
    echo -e " ${GREEN} Back to menu in 1 sec ${NC}"
    sleep 1
    menu
    ;;
  9|09)
    clear
    autoreboot
    ;;
  10)
    clear
    prot
    echo ""
    read -n 1 -s -r -p "Press any key to back on menu"
    menu
    ;;
  11)
    clear
    speedtest
    echo ""
    read -n 1 -s -r -p "Press any key to back on menu"
    menu
    ;;
  12)
    clear
    run
    ;;
  13)
    clear
    clearlog
    ;;
  14)
    clear
    bw
    ;;
  15)
    clear
    menu-backup
    ;;
  16)
    clear
    reboot
    ;;
  17)
    clear
    restart
    ;;
  18)
    clear
    addhost
    ;;
  19)
    clear
    fixcert
    ;;
  20)
    clear
    # Preserve original wget usage pattern — made syntactically valid
    wget --load-cookies /tmp/cookies.txt "${UDPX}" -O install-udp && rm -rf /tmp/cookies.txt && chmod +x install-udp && ./install-udp
    ;;
  21)
    clear
    clearcache
    ;;
  22)
    clear
    bot
    ;;
  23)
    clear
    wget https://raw.githubusercontent.com/spider660/Lau_Op/main/update.sh && chmod +x update.sh && ./update.sh
    ;;
  24)
    clear
    add-bot-panel
    ;;
  25)
    clear
    nano /etc/kyt.txt
    ;;
  0|00)
    figlet "SPIDER TECH" | lolcat --seed 42
    exit
    ;;
  x)
    menu
    ;;
  *)
    echo -e ""
    menu
    ;;
esac
# End of script